#define _GNU_SOURCE
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <pthread.h>
#include <stdbool.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <sched.h>
#include <math.h>
#include <assert.h>
#include "../common/epoll.h"
#include "../common/common.h"
#include "../common/measure.h"

char *server_ip = DEFAULT_SERVER_ADDR;
int server_port = DEFAULT_PORT;
bool with_ack = false;
int conn_num = CONNECT_NUMBER; //connect number default
int num_req = NUM_REQ;
bool waiting_transfer_data = true;
int run_latency = 0; // by default, we run the throughput benchmark
int payload_size = DEFAULT_PAYLOAD_SIZE;
struct CON_INFO *fd_con_info = NULL;
size_t er_start_cycles = 0, er_end_cycles = 0;

void usage(char *program);
void parse_args(int argc, char *argv[]);
void latency_report_perf(size_t *start_cycles, size_t *end_cycles);
void throughput_report_perf(size_t duration);
void latency_write(int sockfd, size_t *start_cycles, size_t *end_cycles);
void latency_write_with_ack(int sockfd, size_t *start_cycles, size_t *end_cycles);
void throughput_write(int sockfd, size_t *start_cycles, size_t *end_cycles);
void throughput_write_with_ack(int sockfd, size_t *start_cycles, size_t *end_cycles);
int connect_setup();
static void
handle_epoll_events(int epfd, struct epoll_event *wait_events, int ret, char *buf);
static void handle_send(int epfd, int socket, char *buf);
static void handle_recv(int epfd, int sockfd, char *buf);

void usage(char *program)
{
    printf("Usage: \n");
    printf("%s\tready to connect %s:%d\n", program, server_ip, server_port);
    printf("Options:\n");
    printf(" -a <addr>      connect to server addr(default %s)\n", DEFAULT_SERVER_ADDR);
    printf(" -p <port>      connect to port number(default %d)\n", DEFAULT_PORT);
    printf(" -c <connection number>   connection size \n");
    printf(" -s <size>      payload size(default %d)\n", DEFAULT_PAYLOAD_SIZE);
    printf(" -n <requests>  the number of request(default %d)\n", NUM_REQ);
    printf(" -w             transfer data with ack\n");
    printf(" -l             run the lantency benchmark\n");
    printf(" -h             display the help information\n");
}

// parsing command line parameters
void parse_args(int argc, char *argv[])
{
    for (int i = 1; i < argc; ++i)
    {
        if (strlen(argv[i]) == 2 && strcmp(argv[i], "-p") == 0)
        {
            if (i + 1 < argc)
            {
                server_port = atoi(argv[i + 1]);
                if (server_port < 0 || server_port > 65535)
                {
                    printf("invalid port number\n");
                    exit(EXIT_FAILURE);
                }
                i++;
            }
            else
            {
                printf("cannot read port number\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-a") == 0)
        {
            if (i + 1 < argc)
            {
                server_ip = argv[i + 1];
                i++;
            }
            else
            {
                printf("cannot read server addr\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-s") == 0)
        {
            if (i + 1 < argc)
            {
                payload_size = atoi(argv[i + 1]);
                if (payload_size <= 0)
                {
                    printf("invalid payload size\n");
                    exit(EXIT_FAILURE);
                }
                i++;
            }
            else
            {
                printf("cannot read payload size\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-w") == 0)
        {
            with_ack = true;
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-c") == 0)
        {
            if (i + 1 < argc)
            {
                conn_num = atoi(argv[i + 1]);
                if (conn_num <= 0)
                {
                    printf("invalid numbers of connection\n");
                    exit(EXIT_FAILURE);
                }
                i++;
            }
            else
            {
                printf("cannot read numbers of connection\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-l") == 0)
        {
            run_latency = 1;
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-n") == 0)
        {
            if (i + 1 < argc)
            {
                num_req = atoi(argv[i + 1]);
                if (num_req <= 0)
                {
                    printf("invalid the number of requests\n");
                    exit(EXIT_FAILURE);
                }
                i++;
            }
            else
            {
                printf("cannot read the number of requests\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-h") == 0)
        {
            usage(argv[0]);
            exit(EXIT_SUCCESS);
        }
        else
        {
            printf("invalid option: %s\n", argv[i]);
            usage(argv[0]);
            exit(EXIT_FAILURE);
        }
    }
}

int main(int argc, char *argv[])
{
    // read command line arguments
    parse_args(argc, argv);
    fd_con_info = init_conn_info(conn_num + 1000); // initialize connection infomation

    struct epoll_event *wait_event = NULL;
    char buf[BUFSIZE];
    int epfd;

    wait_event = (struct epoll_event *)malloc(EPOLLEVENTS * sizeof(struct epoll_event));
    if (wait_event == NULL)
    {
        perror("malloc wait_event memory failed\n");
        exit(EXIT_FAILURE);
    }
    epfd = epoll_create(FDSIZE);
    if (epfd < 0)
    {
        perror("epoll_create failed");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < conn_num; ++i)
    {
        int socket_fd;
        //printf("connect socket:%d\n", i);
        if ((socket_fd = connect_setup(server_port)) < 0)
        {
            perror("connect failed");
            exit(EXIT_FAILURE);
        }
        else
        {
            //printf("socketfd=%d\n",socket_fd);
            fd_con_info[socket_fd].recv_size = 0;
            fd_con_info[socket_fd].send_size = 0;
            set_nonblock(socket_fd);
            epoll_add_event(epfd, socket_fd, EPOLLIN | EPOLLET);
            int n = 0;
            while (n < payload_size)
            {
                n += write(socket_fd, buf, payload_size);
                //puts("client send data\n");
            }
        }
    }

    //printf("going to sleep 3s\n");
    //returnsleep(3); // wait 1s
    //waiting_transfer_data = false;

    //printf("waiting_transfer_data is %d\n", waiting_transfer_data);
    while (true)
    {
        //printf("epoll...\n");
        int ret;
        ret = epoll_wait(epfd, wait_event, EPOLLEVENTS, -1);
        if (ret < 0)
        {
            perror("epoll_wait()");
        }
        handle_epoll_events(epfd, wait_event, ret, buf);
    }
    close(epfd);
    return 0;
}

int connect_setup(int port)
{
    int socket_fd;
    struct sockaddr_in server_addr;
    struct hostent *server;
    if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("create socket failed");
        exit(EXIT_FAILURE);
    }

    //Bind to a specific network interface (and optionally a specific local port)
    // struct sockaddr_in localaddr;
    // localaddr.sin_family = AF_INET;
    // localaddr.sin_addr.s_addr = inet_addr(DEFAULT_LOCALHOST);
    // localaddr.sin_port = 0; // Any local port will do
    // bind(socket_fd, (struct sockaddr *)&localaddr, sizeof(localaddr));

    bzero((char *)&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    inet_pton(AF_INET, server_ip, &server_addr.sin_addr);
    // if ((server = gethostbyname(server_ip)) == NULL)
    // {
    //     perror("server is NULL");
    //     exit(EXIT_FAILURE);
    // }
    printf("connecting to %s:%d\n", server_ip, port);
    // bcopy((char *)server->h_addr, (char *)&server_addr.sin_addr.s_addr, server->h_length);
    if (connect(socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("connect failed");
        exit(EXIT_FAILURE);
    }
    return socket_fd;
}

static void
handle_epoll_events(int epfd, struct epoll_event *wait_events, int ret, char *buf)
{
    int fd;
    for (int i = 0; i < ret; ++i)
    {
        fd = wait_events[i].data.fd;
        if (wait_events[i].events & EPOLLIN)
        {
            handle_recv(epfd, fd, buf); // don't
        }
        else if (wait_events[i].events & (EPOLLERR | EPOLLHUP))
        {
            perror("wait_event: one fd error\n");
            close(fd);
            //close(fd);
            // epoll_modify_event(epfd, fd, EPOLLIN);
        }
    }
    //puts("handle_epoll_events over\n");
}

static void handle_send(int epfd, int sockfd, char *buf)
{

    //printf("start transfer data\n");
    // Determine which function to run based on the parameters
    if (run_latency)
    {
        size_t *start_cycles, *end_cycles;
        start_cycles = (size_t *)malloc(sizeof(size_t) * num_req);
        end_cycles = (size_t *)malloc(sizeof(size_t) * num_req);
        if (with_ack)
        {
            latency_write_with_ack(sockfd, start_cycles, end_cycles);
        }
        else
        {
            latency_write(sockfd, start_cycles, end_cycles);
            //epoll_delete_event(epfd, sockfd, EPOLLOUT);
            close(sockfd);
        }
        latency_report_perf(start_cycles, end_cycles);
        free(start_cycles);
        free(end_cycles);
        close(sockfd);
    }
    else
    {

        if (with_ack)
        {
            throughput_write(sockfd, &er_start_cycles, &er_end_cycles);
            if (fd_con_info[sockfd].send_size >= payload_size * num_req)
            {
                throughput_report_perf(er_end_cycles - er_start_cycles);
                fd_con_info[sockfd].send_size = 0;
            }
        }
        else
        {
            throughput_write(sockfd, &er_start_cycles, &er_end_cycles);
            if (fd_con_info[sockfd].send_size >= payload_size * num_req)
            {
                throughput_report_perf(er_end_cycles - er_start_cycles);
                fd_con_info[sockfd].send_size = 0;
            }
        }
    }
    return;
}

// measure latency without ack after writing message
void latency_write(int sockfd, size_t *start_cycles, size_t *end_cycles)
{
    char msg[payload_size];
    for (size_t i = 0; i < num_req; i++)
    {
        size_t n = 0;
        start_cycles[i] = get_cycles();
        while (n < payload_size)
            n += write(sockfd, msg, payload_size);
        end_cycles[i] = get_cycles();
    }
}

// measure latency with reading ack after writing message
void latency_write_with_ack(int sockfd, size_t *start_cycles, size_t *end_cycles)
{ //
    char msg[payload_size];
    char ack = '1';
    for (size_t i = 0; i < num_req; ++i)
    {
        start_cycles[i] = get_cycles();
        int n = 0;
        while (n >= payload_size)
            n += write(sockfd, msg, payload_size);
        n = 0;
        while (n >= 1)
            n += read(sockfd, &ack, sizeof(ack));
        end_cycles[i] = get_cycles();
    }
}

// measure throughput without ack after writing message
void throughput_write(int sockfd, size_t *start_cycles, size_t *end_cycles)
{ 
    char msg[payload_size];
    size_t nwrite = 0;
    int n = 0;
    while (nwrite < payload_size * num_req)
    {
        n = write(sockfd, msg, payload_size);
        if (n == -1)
        {
            perror("write error:");
            epoll_delete_event(epfd, sockfd, EPOLLIN);
            close(sockfd);
            fd_con_info[sockfd].recv_size = fd_con_info[sockfd].send_size = 0;
            return;
        }
        else if (n == 0)
        {
            perror("client close.\n");
            epoll_delete_event(epfd, sockfd, EPOLLIN);
            close(sockfd);
            fd_con_info[sockfd].recv_size = fd_con_info[sockfd].send_size = 0;
            return;
        }else{
            nwrite += n;
        }
    }
    return;
}

// measure throughput with reading ack after writing message
void throughput_write_with_ack(int sockfd, size_t *start_cycles, size_t *end_cycles)
{
    char msg[payload_size];
    if (fd_con_info[sockfd].send_size == 0)
    {
        puts("Socket start data\n");
        *start_cycles = get_cycles();
    }
    int nwrite = 0;
    while (nwrite < payload_size)
    {
        nwrite += write(sockfd, msg, payload_size);
    }
    fd_con_info[sockfd].send_size += nwrite;

    if (fd_con_info[sockfd].send_size >= payload_size * num_req)
    {
        puts("finsh1\n");
        *end_cycles = get_cycles();
        close(sockfd);
    }
}
// print latency performance data
void latency_report_perf(size_t *start_cycles, size_t *end_cycles)
{
    double *lat = (double *)malloc(num_req * sizeof(double));
    double cpu_mhz = get_cpu_mhz();
    double sum = 0.0;
    // printf("\nbefore sort:\n");
    for (size_t i = 0; i < num_req; i++)
    {
        lat[i] = (double)(end_cycles[i] - start_cycles[i]) / cpu_mhz;
        sum += lat[i];
    }
    qsort(lat, num_req, sizeof(lat[0]), cmp);
    size_t idx_m, idx_99, idx_99_9, idx_99_99;
    idx_m = floor(num_req * 0.5);
    idx_99 = floor(num_req * 0.99);
    idx_99_9 = floor(num_req * 0.999);
    idx_99_99 = floor(num_req * 0.9999);
    //printf("idx_99 = %lu; idx_99_t = %lu; idx_99_99 = %lu\n", idx_99, idx_99_9, idx_99_99);
    printf("@MEASUREMENT(requests = %d, payload size = %d):\n", num_req, payload_size);
    printf("MEDIAN = %.2f us\n50 TAIL = %.2f us\n99 TAIL = %.2f us\n99.9 TAIL = %.2f us\n99.99 TAIL = %.2f us\n", sum / num_req, lat[idx_m], lat[idx_99], lat[idx_99_9], lat[idx_99_99]);
    free(lat);
}

// print throughput performance data
void throughput_report_perf(size_t duration)
{
    double cpu_mhz = get_cpu_mhz();
    double total_time = (double)duration / cpu_mhz;
    // throughtput
    double tput1 = (double)num_req / total_time * 1000000;
    // bandwidth
    double tput2 = (double)(num_req) / total_time * payload_size;
    printf("@MEASUREMENT(requests = %d, payload size = %d):\n", num_req, payload_size);
    printf("total time = %.2f us\n", total_time);
    printf("THROUGHPUT1 = %.2f REQ/s\n", tput1);
    printf("THROUGHPUT2 = %.2f Mb/s\n", tput2 * 8);
}

static void handle_recv(int epfd, int sockfd, char *buf)
{
    //epoll_delete_event(epfd, sockfd, EPOLLIN);
    //lose(sockfd);
    //printf("close ok\n");
    //return;
    int nwriter = 0;
    while (nwriter < payload_size)
        nwriter += read(sockfd, buf, payload_size);
    handle_send(epfd, sockfd, buf);
}
