#define _GNU_SOURCE
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <stdbool.h>
#include <fcntl.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/time.h>
#include <sched.h>
#include <error.h>
#include <assert.h>
#include "../common/common.h"
#include "../common/epoll.h"
#include "../common/measure.h"

char *server_ip = DEFAULT_SERVER_ADDR;
int server_port = DEFAULT_PORT;
int num_req = NUM_REQ;
bool with_ack = false;
int run_latency = 0; // by default, we run the throughput benchmark
int payload_size = DEFAULT_PAYLOAD_SIZE;
int conn_num = CONNECT_NUMBER; //connect number default 1
struct CON_INFO *fd_con_info = NULL;
size_t start_cycles = NULL;
size_t end_cycles = NULL;
size_t TOTAL_RECV_PACKAGET = 0;

void usage(char *program);
void parse_args(int argc, char *argv[]);
void latency_read(int epfd, int sockfd, char *buf);
void latency_read_with_ack(int epfd, int sockfd, char *buf);
static void do_epoll(int listenfd);
static void
handle_epoll_events(int epollfd, struct epoll_event *events, int num, int listenfd, char *buf);
static void handle_accpet(int epollfd, int listenfd);
static void handle_recv(int epfd, int fd, char *buf);
static void handle_send(int epfd, int fd, char *buf);
void throughput_report_perf(size_t duration, size_t pakcnt);

// void throughput_read(int sockfd);
// void throughput_read_with_ack(int sockfd);

void usage(char *program)
{
    printf("Usage: \n");
    printf("%s\tstart a server and wait for connection\n", program);
    printf("Options:\n");
    printf(" -p <port>      listen on port number(default %d)\n", DEFAULT_PORT);
    printf(" -a <addr>      connect to server addr(default %s)\n", DEFAULT_SERVER_ADDR);
    printf(" -c <connection number>   connection size \n");
    printf(" -s <size>      payload size(default %d)\n", DEFAULT_PAYLOAD_SIZE);
    printf(" -n <requests>  the number of request(default %d)\n", NUM_REQ);
    printf(" -w             transfer data with ack\n");
    printf(" -l             run the lantency benchmark\n");
    printf(" -h             display the help information\n");
}

void parse_args(int argc, char *argv[])
{
    for (int i = 1; i < argc; ++i)
    {
        if (strlen(argv[i]) == 2 && strcmp(argv[i], "-p") == 0)
        {
            if (i + 1 < argc)
            {
                server_port = atoi(argv[i + 1]);
                if (server_port < 0 || server_port > 65535)
                {
                    printf("invalid port number\n");
                    exit(EXIT_FAILURE);
                }
                i++;
            }
            else
            {
                printf("cannot read port number\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-a") == 0)
        {
            if (i + 1 < argc)
            {
                server_ip = argv[i + 1];
                i++;
            }
            else
            {
                printf("cannot read server addr\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-s") == 0)
        {
            if (i + 1 < argc)
            {
                payload_size = atoi(argv[i + 1]);
                if (payload_size <= 0)
                {
                    printf("invalid payload size\n");
                    exit(EXIT_FAILURE);
                }
                i++;
            }
            else
            {
                printf("cannot read payload size\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-c") == 0)
        {
            if (i + 1 < argc)
            {
                conn_num = atoi(argv[i + 1]);
                if (conn_num <= 0)
                {
                    printf("invalid numbers of connection\n");
                    exit(EXIT_FAILURE);
                }
                i++;
            }
            else
            {
                printf("cannot read numbers of connection\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-w") == 0)
        {
            with_ack = true;
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-l") == 0)
        {
            run_latency = 1;
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-n") == 0)
        {
            if (i + 1 < argc)
            {
                num_req = atoi(argv[i + 1]);
                if (num_req <= 0)
                {
                    printf("invalid the number of requests\n");
                    exit(EXIT_FAILURE);
                }
                i++;
            }
            else
            {
                printf("cannot read the number of requests\n");
                usage(argv[0]);
                exit(EXIT_FAILURE);
            }
        }
        else if (strlen(argv[i]) == 2 && strcmp(argv[i], "-h") == 0)
        {
            usage(argv[0]);
            exit(EXIT_SUCCESS);
        }
        else
        {
            printf("invalid option: %s\n", argv[i]);
            usage(argv[0]);
            exit(EXIT_FAILURE);
        }
    }
}

int main(int argc, char *argv[])
{

    int listen_fd;
    struct sockaddr_in address;

    // read command line arguments
    parse_args(argc, argv);

    //in order to store the connection information: recv_size and send_size
    fd_con_info = init_conn_info(conn_num + 100); // initialize connection infomation

    if ((listen_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("create socket failed");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = inet_addr(server_ip);
    address.sin_port = htons(server_port);
    printf("bind to %s:%d\n", server_ip, server_port);
    if (bind(listen_fd, (struct sockaddr *)&address, sizeof(address)))
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    if (listen(listen_fd, SOCK_BACKLOG_CONN) < 0)
    {
        perror("listen failed");
        exit(EXIT_FAILURE);
    }
    printf("server listens on 0.0.0.0:%d\n", server_port);
    do_epoll(listen_fd);
    close(listen_fd);
    return 0;
}

void do_epoll(int listen_fd)
{
    struct epoll_event wait_event[EPOLLEVENTS];
    char buf[BUFSIZE];

    int epfd;
    epfd = epoll_create(FDSIZE);
    if (epfd < 0)
    {
        perror("epoll_create failed");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    set_nonblock(listen_fd);
    epoll_add_event(epfd, listen_fd, EPOLLIN | EPOLLET);

    while (true)
    {
        //printf("epoll...\n");
        int ret;
        ret = epoll_wait(epfd, wait_event, EPOLLEVENTS, -1);
        if (ret < 0)
        {
            perror("epoll_wait()");
        }
        handle_epoll_events(epfd, wait_event, ret, listen_fd, buf);
    }
    close(epfd);
}

void latency_read(int epfd, int sockfd, char *buf)
{
    // for (int i = 0; i < num_req; ++i)
    int n = 0;
    while (n < payload_size)
    {
        int t = 0;
        t = read(sockfd, buf, payload_size);
        if (t == -1)
        {
            perror("read error:");
            epoll_delete_event(epfd, sockfd, EPOLLIN);
            close(sockfd);
            return;
        }
        else if (t == 0)
        {
            fprintf(stderr, "client close.\n");
            epoll_delete_event(epfd, sockfd, EPOLLIN);
            close(sockfd);
            fd_con_info[sockfd].recv_size = 0;
            return;
        }
        n += t;
    }

    TOTAL_RECV_PACKAGET++;

    fd_con_info[sockfd].recv_size += n;
    if (fd_con_info[sockfd].recv_size >= num_req * payload_size)
    {
        epoll_delete_event(epfd, sockfd, EPOLLIN);
        close(sockfd);
        //puts("close1\n");
        fd_con_info[sockfd].recv_size = 0;
    }
    return;
}

void latency_read_with_ack(int epfd, int sockfd, char *buf)
{

    int n = 0;
    //puts("recv data ing\n");
    while (n < payload_size)
    {
        n += read(sockfd, buf, payload_size);
        TOTAL_RECV_PACKAGET++;
        // if (n == -1)
        // {
        //     perror("read error:");
        //     epoll_delete_event(epfd, sockfd, EPOLLIN);
        //     close(sockfd);
        //     fd_con_info[sockfd].recv_size = fd_con_info[sockfd].send_size = 0;
        //     return;
        // }
        // else if (n == 0)
        // {
        //     fprintf(stderr, "client close.\n");
        //     epoll_delete_event(epfd, sockfd, EPOLLIN);
        //     close(sockfd);
        //     fd_con_info[sockfd].recv_size = fd_con_info[sockfd].send_size = 0;
        //     return;
        // }
        // fd_con_info[sockfd].recv_size += n;
        // if (fd_con_info[sockfd].recv_size >= payload_size)
        // {
        //     //epoll_modify_event(epfd, sockfd, EPOLLOUT);
        //     fd_con_info[sockfd].recv_size -= payload_size;
        // }
    }

    static void
    handle_epoll_events(int epfd, struct epoll_event *wait_events, int ret, int listen_fd, char *buf)
    {
        int fd;
        for (int i = 0; i < ret; ++i)
        {
            fd = wait_events[i].data.fd;
            if (wait_events[i].events & (EPOLLERR | EPOLLHUP))
            {
                perror("wait_event: one fd error\n");
                close(fd);
            }
            else if ((fd == listen_fd) && wait_events[i].events & EPOLLIN)
                handle_accpet(epfd, listen_fd);
            else if (wait_events[i].events & EPOLLIN)
                handle_recv(epfd, fd, buf);
            else if (wait_events[i].events & EPOLLOUT)
                handle_send(epfd, fd, buf);
        }
    }

    static void handle_accpet(int epfd, int listen_fd)
    {
        int sockfd;
        struct sockaddr_in cli_addr;
        socklen_t cli_len = sizeof(cli_addr);
        memset(&cli_addr, 0, sizeof(cli_addr));

        sockfd = accept(listen_fd, (struct sockaddr *)&cli_addr, &cli_len);
        if (sockfd < 0)
        {
            perror("accept failed");
            close(listen_fd);
            exit(EXIT_FAILURE);
        }
        else
        {
            printf("fd=%d\n", sockfd);
            printf("accept a new client: %s:%d\n", inet_ntoa(cli_addr.sin_addr), cli_addr.sin_port);
            set_nonblock(sockfd);
            fd_con_info[sockfd].recv_size = 0;
            fd_con_info[sockfd].send_size = 0;
            epoll_add_event(epfd, sockfd, EPOLLIN | EPOLLET);
        }
        return;
    }

    static void handle_recv(int epfd, int fd, char *buf)
    {
        //int nread; //recv size
        //struct timeval curr_time;
        //    gettimeofday(&curr_time, NULL);
        //   printf("waiting for transfer data on %d, time is %ld.%ld\n", fd, curr_time.tv_sec, curr_time.tv_usec);
        //    nread = read(fd, buf, BUFSIZE);
        //gettimeofday(&curr_time, NULL);
        //printf("start transfer data, time is %ld.%ld\n", curr_time.tv_sec, curr_time.tv_usec);
        if (start_cycles == NULL)
        {
            start_cycles = get_cycles();
        }
        latency_read(epfd, fd, buf);
        if (with_ack)
        {

            handle_send(epfd, fd, buf);
        }

        if (TOTAL_RECV_PACKAGET >= num_req)
        {
            throughput_report_perf(get_cycles() - start_cycles, TOTAL_RECV_PACKAGET);
            start_cycles = 0;
            TOTAL_RECV_PACKAGET = 0;
        }

        return;
    }

    static void handle_send(int epfd, int fd, char *buf)
    {
        // int nwrite = 0;
        // if (run_latency)
        // {
        //     nwrite = write(fd, buf, payload_size);
        //     if (nwrite == -1)
        //     {
        //         perror("write error:");
        //         //epoll_delete_event(epfd, fd, EPOLLOUT);
        //         close(fd);
        //         fd_con_info[fd].recv_size = fd_con_info[fd].send_size = 0;
        //     }
        //     fd_con_info[fd].send_size += nwrite;
        //     if (fd_con_info[fd].send_size >= payload_size)
        //     {
        //         fd_con_info[fd].send_size -= payload_size;
        //         //epoll_modify_event(epfd, fd, EPOLLIN);
        //     }
        // }
        // else
        // { //throughput_write_with_ack
        //read payloadsize and  write ack 1
        while (nwrite < payload_size)
        {
            int n = 0;
            n = write(fd, buf, payload_size);
            if (n == -1)
            {
                perror("write error:");
                epoll_delete_event(epfd, fd, EPOLLOUT);
                close(fd);
                //fd_con_info[fd].recv_size = fd_con_info[fd].send_size = 0;
            }
            nwrite += n;
        }

        return;
    }

    void throughput_report_perf(size_t duration, size_t pakcnt)
    {
        double cpu_mhz = get_cpu_mhz();
        double total_time = (double)duration / cpu_mhz;
        // throughtput
        double tput1 = (double)pakcnt / total_time * 1000000;
        // bandwidth
        printf("@MEASUREMENT(requests = %d, payload size = %d):\n", num_req, payload_size);
        printf("total time = %.2f us\n", total_time);
        printf("THROUGHPUT = %.2f REQ/s\n", tput1);
        // printf("THROUGHPUT2 = %.2f Mb/s\n", tput2 * 8);
    }